using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Hosting;
using System.Web.Mvc;
using DevExpress.DashboardCommon;
using DevExpress.DashboardWeb.Mvc;

namespace DXWebApplication7.Controllers {
    public class DefaultDashboardController : DashboardController {

    }
}